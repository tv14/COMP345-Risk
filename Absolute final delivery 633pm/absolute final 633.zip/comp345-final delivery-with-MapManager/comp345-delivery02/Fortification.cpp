#include <list>

#include "Fortification.h"
#include <list>
#include <iostream>
using namespace std;

Fortification::Fortification(Player& p1, vector<Country> &listofcountries): listofcountries(listofcountries) {
    this->currentplayer=&p1;
}

void Fortification::setMovingFrom(){
    std::string chosenmovingcountry;
    bool check=true;
    
    while (check)
    {
        std::cout <<"Please choose country to move units from:\t"; //user inputs a country to move from
		getline(cin, chosenmovingcountry);
        
        for (int indexofcountries=0;indexofcountries<listofcountries.size();indexofcountries++)//checks for all countries
        {
        	Country toMove = listofcountries[indexofcountries];
            if (toMove.getName()==chosenmovingcountry)//program checks if user inputted a proper country
            {
                if (toMove.getOwner()->getPlayerName()==this->currentplayer->getPlayerName())//checks to see if user inputted a country he owns
                {
                    this->movingfrom=&this->listofcountries[indexofcountries];
                    
                    if (this->Fortification::noPath())//returns a statement if there is no adjacent enemy country to attack.
                    {
                        std::cout <<"There is no adjacent allied country to move to. Please choose another country." <<std::endl;
                    }
                    else
                    {
                         std::cout<< "You are moving from: \t" << toMove.getName() <<std::endl;
                         check=false;
                    }
                }
                else {
                 std::cout <<"You do not own that country" <<std::endl;   
                }
            }
        }
    }
}

/*
 * checks if there any allied adjacent armies beside the selected moving country
 */
bool Fortification::noPath(){
   bool nopath=true;
   for (int indexofcountries=0;indexofcountries<listofcountries.size();indexofcountries++)
   {
	   Country adjacentC = listofcountries[indexofcountries];
	   string adjacentCSTR =  adjacentC.getName();
       if (movingfrom->isAdjacent(adjacentCSTR))//checks to see if the countries are adjacent
       {
           if (movingfrom->getOwner()->getPlayerName()==adjacentC.getOwner()->getPlayerName())//checks to see if the countries are owned by the same player
           {
               nopath=false;
               break;
           }
       }
   }
   return nopath;
}

void Fortification::setMovingTo(){
   std::string chosenmovingto;
    bool check=true;
    while (check) {
        std::cout << "Please choose an country that you own to move to:\t";
		getline(cin, chosenmovingto);
        for (int indexofcountries=0;indexofcountries<listofcountries.size();indexofcountries++)
        {
        	Country movintoC = listofcountries[indexofcountries];
        	string movintoCSTR = movintoC.getName();

            if (movintoC.getName()==chosenmovingto)//program checks if the user inputted a proper country else displays error message
            {
                if (movintoC.getOwner()->getPlayerName()==currentplayer->getPlayerName())//checks if the player owns that country else displays error message
                {
                    if (this->movingfrom->isAdjacent(movintoCSTR))//checks to see if the inputted country has a path
                    {
                        this->movingto=&this->listofcountries[indexofcountries];//if there is a path, the program displays a success message and sets the country to be moved to
                        std::cout<< "You are moving to:\t" << movintoCSTR << std::endl;
                        check=false;
                    }
                    else {
                        std::cout<<"There is no path to country:\t" <<chosenmovingto <<std::endl;
                    }
                }
                else {
                    std::cout <<"You do not own that country" <<std::endl;  
                }
            }
        }
    }
}

/*
 * Checks if there exists a path of adjacent allied countries between the moving country and another country
 */
bool Fortification::hasAPath(Country &c){
	string name = c.getName();
	return (movingfrom->isAdjacent(name));
}

/*
 * Moves the desired amount of armies to the desired country
 */
string Fortification::moveArmy() {
	stringstream returnoutput;
	std::cout<< "How many armies do you wish to move from " <<movingfrom->getName() << " to " << movingto->getName() << " (1-" 
            <<movingfrom->getArmyCount()-1 << "):\t";
    int armycount;
	string armycountinput;
    bool check=true;
    while (check)
    {
		getline(cin, armycountinput);
		stringstream stream(armycountinput);
 
        if (stream >> armycount && armycount>0 && armycount<movingfrom->getArmyCount())
            {
            check=false;
            }
    }
    
    movingfrom->setArmyCount(movingfrom->getArmyCount()-armycount);
    movingto->setArmyCount(movingto->getArmyCount()+armycount);
    std::cout<<armycount <<" armies have been moved from " <<movingfrom->getName() << " to " <<movingto->getName()<<std::endl;
	returnoutput << armycount << " armies have been moved from " << movingfrom->getName() << " to " << movingto->getName() << "." << std::endl;
    
	return returnoutput.str();        
}
